package com.fis.bankapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapp.model.Transaction;
import com.fis.bankapp.service.TransactionService;
import com.fis.bankapp.dao.TransactionDao;


@Service
@Transactional
public class TransactionServiceImpl implements TransactionService{
	
	
	@Autowired
	TransactionDao dao;

	@Override
	public String addTransaction(Transaction transaction) {
		dao.save(transaction);
		return "Transaction added";
	}

	@Override
	public List<Transaction> getTransactions(long AccNoFrom) {
		// TODO Auto-generated method stub
		return dao.getTransaction(AccNoFrom);
	}

	@Override
	public List<Transaction> getAllTransactions() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}
}

