package com.fis.bankapp.service;

import java.util.List;

import com.fis.bankapp.model.Customer;
import com.fis.bankapp.exception.CustomerNotFound;

public interface CustomerService {
	public abstract String addCustomer(Customer customer);

	public abstract String updateCustomer(Customer customer) throws CustomerNotFound;

	public abstract String deleteCustomer(int custId) throws CustomerNotFound;

	public abstract Customer getCustomer(int custId) throws CustomerNotFound;

	public abstract List<Customer> getAllCustomers();

}
