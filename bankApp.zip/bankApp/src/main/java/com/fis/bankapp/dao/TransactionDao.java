package com.fis.bankapp.dao;

import java.util.ArrayList;
import java.util.List;

import com.fis.bankapp.model.Transaction;

public interface TransactionDao {
	
	
	public abstract String addTransaction(Transaction transaction);
	
	public List<Transaction> getTransactions(long AccNoFrom);
	
	public List<Transaction> getAllTransactions();
}
