package com.fis.bankapp.service;

import java.util.List;

import com.fis.bankapp.model.Transaction;

public interface TransactionService {
	
	
	public abstract String addTransaction(Transaction transaction);
	
	public List<Transaction> getTransactions(long AccNoFrom);
	
	public List<Transaction> getAllTransactions();
}
