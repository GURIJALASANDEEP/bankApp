package com.fis.bankapp.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapp.model.Customer;
import com.fis.bankapp.dao.CustomerDao;
import com.fis.bankapp.exception.CustomerNotFound;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	CustomerDao dao;

	@Override
	public String addCustomer(Customer customer) {

		return dao.addCustomer(customer);
	}

	/*@Override
	public String updateCustomer(Customer customer) throws CustomerNotFound {
		return dao.updateCustomer(customer);
	}*/

	@Override
	public String deleteCustomer(int custId) throws CustomerNotFound {
		return dao.deleteCustomer(custId);
	}

	@Override
	public Customer getCustomer(int custId) throws CustomerNotFound {
		return dao.getCustomer(custId);
	}

	@Override
	public List<Customer> getAllCustomers() {
		return dao.getAllCustomers();
	}

	

}
