package com.fis.bankapp.dao;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.fis.bankapp.exception.AccountNotFound;
import com.fis.bankapp.exception.NotEnoughBalance;
import com.fis.bankapp.model.Account;
import com.fis.bankapp.model.Customer;
import com.fis.bankapp.model.Transaction;


@Repository
public class AccountDaoImpl implements AccountDao {

	
	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public String addAccount(Account account) {
		entityManager.persist(account);
		return "Account Created Successfully";
	}
	
	/*@Override
	public String updateAccount(Account account) {
		entityManager.merge(account);
		return "Account Updated Successfully";
	}*/

	@Override
	public String deleteAccount(long accNo) throws AccountNotFound {
		if(entityManager.find(Account.class, accNo) != null){
			entityManager.remove(getAccount(accNo));
			return "Account Removed Successfully";
	} else {
		throw new AccountNotFound("Invalid Account Number");
	}
	}

	@Override
	public Account getAccount(long accNo) throws AccountNotFound {
		if(entityManager.find(Account.class, accNo) != null){
			return entityManager.find(Account.class, accNo);
	} else {
		throw new AccountNotFound("Invalid Account Number");
	}

		
	}
	

	@Override
	public String depositIntoBalance(long accNo, double depositAmount) {
		// TODO Auto-generated method stub
		//TypedQuery<Account> query = entityManager.createQuery("Update Account a set a.balance=a.balance+?1 where accNum=?2 ", Account.class);
		//query.setParameter(1, depositAmount);
		//query.setParameter(2, accNum);
		//query.executeUpdate();
		Account account1= entityManager.find(Account.class, accNo);
		double currBalance=account1.getBalance();
		double updatedBalance=currBalance+depositAmount;
		account1.setBalance(updatedBalance);
		entityManager.merge(account1);
		Transaction transaction1=new Transaction();
		int transId = 0;
		transaction1.setTransId(transId);
		transId++;
		transaction1.setAmount(depositAmount);
		//transaction1.setStatus("Success");
		transaction1.setAccNoTo(0);
		transaction1.setAccNoFrom(accNo);
		transaction1.setTransType("Deposit");
		entityManager.merge(transaction1);
		return "Deposited Successfully";
	}

	@Override
	public String withdrawFromBalance(long accNo, double withdrawAmount) throws NotEnoughBalance{
		// TODO Auto-generated method stub

		Account account2= entityManager.find(Account.class, accNo);
		double currBalance=account2.getBalance();
		Transaction transaction1=new Transaction();
		int transId = 0;
		transaction1.setTransId(transId);
		transId++;
		transaction1.setAmount(withdrawAmount);
		transaction1.setAccNoTo(0);
		transaction1.setAccNoFrom(accNo);
		transaction1.setTransType("Withdraw");
		if(currBalance-withdrawAmount>0) {
			double updatedBalance=currBalance-withdrawAmount;
			account2.setBalance(updatedBalance);
			entityManager.merge(account2);
			//transaction1.setStatus("Success");
			entityManager.merge(transaction1);
			return "Withdrawn Successfully";
		} else {
			throw new NotEnoughBalance("Not Enough Balance");
		}
	}

	@Override
	public String FundTransfer(long AccNoFrom, long AccNoTo, double amount, String transType) {
		// TODO Auto-generated method stub
		Account account1= entityManager.find(Account.class, AccNoFrom);
		Account account2= entityManager.find(Account.class, AccNoTo);
		double account1Balance=account1.getBalance();
		Transaction transaction1=new Transaction();
		int transId = 0;
		transaction1.setTransId(transId );
		transId++;
		transaction1.setAmount(amount);
		transaction1.setAccNoTo(AccNoTo);
		transaction1.setAccNoFrom(AccNoFrom);
		transaction1.setTransType("FundTransfer:" + transType);
		if(account1Balance-amount<0) {
			//transaction1.setStatus("Failed");
			entityManager.merge(transaction1);
			return "Insufficient Balance";
		}
		account1.setBalance(account1Balance-amount);
		account2.setBalance(account2.getBalance()+amount);
		//transaction1.setStatus("Success");
		entityManager.merge(transaction1);
		return "Fund Transfered Successfully";
	}
}
