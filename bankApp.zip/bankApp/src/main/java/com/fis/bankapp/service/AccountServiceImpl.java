package com.fis.bankapp.service;

import java.util.List;
import java.util.HashMap;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapp.model.Account;
import com.fis.bankapp.dao.AccountDao;
import com.fis.bankapp.exception.AccountNotFound;
import com.fis.bankapp.exception.NotEnoughBalance;


@Service
@Transactional
public class AccountServiceImpl implements AccountService {
	@Autowired
	AccountDao dao;
	

	@Override
	public String addAccount(Account account) {
		return dao.addAccount(account);

	}
	
	@Override
	public String deleteAccount(long accNo) throws AccountNotFound {

		return dao.deleteAccount(accNo);
	}


	@Override
	public Account getAccount(long getAcc) throws AccountNotFound {
		return dao.getAccount(getAcc);

	}

	@Override
	public String depositIntoBalance(long accNo, double depositAmount) {
		// TODO Auto-generated method stub
		return dao.depositIntoBalance(accNo, depositAmount);
	}

	@Override
	public String withdrawFromBalance(long accNo, double withdrawAmount) throws NotEnoughBalance {
		// TODO Auto-generated method stub
		return dao.withdrawFromBalance(accNo, withdrawAmount);
	}

	@Override
	public String FundTransfer(long fromAccount, long toAccount, double amount, String transType) {
		// TODO Auto-generated method stub
		return dao.FundTransfer(fromAccount, toAccount, amount, transType);
	}

}

