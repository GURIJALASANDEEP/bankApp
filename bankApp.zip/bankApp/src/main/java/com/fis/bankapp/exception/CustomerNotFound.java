package com.fis.bankapp.exception;

public class CustomerNotFound extends Exception {

	public CustomerNotFound(String message) {
		super(message);
	}

}
