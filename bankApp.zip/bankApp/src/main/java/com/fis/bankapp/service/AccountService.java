package com.fis.bankapp.service;

import java.util.List;

import com.fis.bankapp.model.Account;
import com.fis.bankapp.exception.NotEnoughBalance;
import com.fis.bankapp.exception.AccountNotFound;

public interface AccountService {
	public abstract String addAccount(Account account);
	
	public abstract String updateAccount(Account account);
	
	public abstract String deleteAccount(long accNo) throws AccountNotFound;

	public abstract Account getAccount(long getAcc) throws AccountNotFound;
	
	public abstract String withdrawFromBalance(long AccNo, double withdrawAmount) throws NotEnoughBalance;

	public abstract String depositIntoBalance(long AccNo, double depositAmount);
	
	public abstract String FundTransfer(long AccNoFrom,long AccNoTo,double amount, String transType);

}
