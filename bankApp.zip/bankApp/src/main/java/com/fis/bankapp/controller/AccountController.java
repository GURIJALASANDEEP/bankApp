package com.fis.bankapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankapp.exception.AccountNotFound;
import com.fis.bankapp.exception.NotEnoughBalance;
import com.fis.bankapp.model.Account;
import com.fis.bankapp.service.AccountService;

//{
//"productId":111,
//"productName":"samsung",
//"productPrice":93000,
//"productCategory":"electronics"
//}
@RestController
@RequestMapping("/accounts")
public class AccountController {
	@Autowired
	AccountService service;

	@PostMapping("/addAccount") // http://localhost:8080/accounts/addAccount
	public String saveAccount(@RequestBody Account account) {
		return service.addAccount(account);
	}

	/*@PutMapping("/updateAccount") // http://localhost:8080/accounts/updateAccount
	public String updateAccount(@RequestBody Account account) {
		return service.updateAccount(account);
	}*/

	@DeleteMapping("/deleteAccount/{accNo}") // http://localhost:8080/accounts/deleteAccount/888
	public String deleteAccount(@PathVariable("accNo") long accNo) throws AccountNotFound {
		try {
			return service.deleteAccount(accNo);
	}
		catch (AccountNotFound neb) {
			return "Account Not Found with given Account Number";
			
		}
	}

	@GetMapping("/getAccount/{accNo}") // http://localhost:8080/accounts/getAccount/888
	public Account getAccount(@PathVariable("accNo") long accNo) throws AccountNotFound {
		
		return service.getAccount(accNo);
	
	}

	/*@GetMapping("/getAllAccounts") // http://localhost:8080/accounts/getAllAccounts
	public List<Account> getAccounts() {
		return service.getAllAccounts();
	}*/
	
	@PostMapping("/depositIntoBalance/{accNo}/{depositAmount}") // http://localhost:8080/accounts/depositIntoBalance/888/888
	public String depositIntoBalance(@PathVariable("accNo") long accNo,@PathVariable("depositAmount") double depositAmount) {
		return service.depositIntoBalance(accNo, depositAmount);
	}
	
	@PostMapping("/withdrawFromBalance/{accNo}/{withdrawAmount}") // http://localhost:8080/accounts/withdrawFromBalance/888/888
	public String withdrawFromBalance(@PathVariable("accNo") long accNo,@PathVariable("withdrawAmount") double withdrawAmount) throws NotEnoughBalance {
		try {
			return service.withdrawFromBalance(accNo, withdrawAmount);
	}
		catch (NotEnoughBalance neb) {
			return "Not Enough Balance";
			
		}
	}
		
	
	//public abstract String FundTransfer(long fromAccount,long toAccount,double amount, String transType);
	@PostMapping("/FundTransfer/{AccNoFrom}/{AccNoTo}/{amount}/{transType}") // http://localhost:8080/accounts/FundTransfer/1/2/1000/NEFT
	public String FundTransfer(@PathVariable("AccNoFrom") long AccNoFrom,@PathVariable("AccNoTo") long AccNoTo,@PathVariable("amount") double amount,@PathVariable("transType") String transType) {
		return service.FundTransfer(AccNoFrom,AccNoTo, amount,transType);
	}


}
